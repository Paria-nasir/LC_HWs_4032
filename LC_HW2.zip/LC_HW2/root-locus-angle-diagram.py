import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.set_aspect('equal')

ax.set_xlim(-5, 1)
ax.set_ylim(-4, 4)
ax.set_title('Root Locus Angle Contribution Diagram')

points = {'A': (-4, 3), 'B': (-4, -3), 'C': (-2.5, 0), 'D': (-1, 0)}

ax.plot(0, 0, 'ko')
ax.text(0, 0.1, 'O', ha='center')

for lbl, p in points.items():
    ax.plot(p[0], p[1], 'ko')
    ax.text(p[0], p[1] + 0.2, lbl, ha='center')
    if lbl == 'A' or lbl == 'B':
        ax.plot([0, p[0]], [0, p[1]], 'k--')
    else:
        ax.plot([0, p[0]], [0, p[1]], 'k-')

ax.text(-2.7, 1.1, r'$\psi/2$', fontsize=12)
ax.text(-2.7, -1.3, r'$\psi/2$', fontsize=12)

ax.set_ylabel(r'$j\omega$')
ax.set_xlabel(r'$\sigma$')
ax.grid(True)

plt.show()

