import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 3, 1000)
y = 1 - 0.21*np.exp(-4*t)*np.cos(10*t)

plt.plot(t, y, label='System: g', color='orange')

plt.axhline(1, linestyle='--', color='gray', linewidth=0.7)
plt.axhline(1.21, linestyle='--', color='gray', linewidth=0.7)
plt.axvline(0.855, linestyle='--', color='gray', linewidth=0.7)
plt.axvline(2.05, linestyle='--', color='gray', linewidth=0.7)

plt.text(0.91, 0.2, 'At time (s): 0.855', fontsize=9)
plt.text(0.1, 1.23, 'Peak amplitude: 1.21', fontsize=9)
plt.text(2.1, 0.7, 'Settling time (s): 2.05', fontsize=9)

plt.xlabel("Time (seconds)")
plt.ylabel("Amplitude")
plt.title("Step Response")
plt.grid(True)
plt.ylim(0, 1.4)

plt.show()
